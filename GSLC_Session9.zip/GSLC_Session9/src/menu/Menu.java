package menu;

import connection.CustomCsvConnection;
import facade.CsvFacade;

import java.util.Scanner;

public class Menu {
	public static void main(String[] args) {
		CustomCsvConnection connection = CustomCsvConnection.getInstance();
		String userCsvPath = "path/to/user.csv";
		String teamCsvPath = "path/to/team.csv";

		CsvFacade csvFacade = new CsvFacade(connection, userCsvPath, teamCsvPath);

		Scanner scanner = new Scanner(System.in);

		while (true) {
			displayMenu();
			int choice = scanner.nextInt();

			switch (choice) {
			case 1:
				// Implement Insert Data
				insertDataMenu(scanner, csvFacade);
				break;
			case 2:
				// Implement Show
				showMenu(scanner, csvFacade);
				break;
			case 3:
				// Implement Exit
				System.out.println("Exiting program.");
				System.exit(0);
			default:
				System.out.println("Invalid choice. Please try again.");
			}
		}
	}

	private static void displayMenu() {
		System.out.println("Menu:");
		System.out.println("1. Insert Data");
		System.out.println("2. Show");
		System.out.println("3. Exit");
		System.out.print("Choose an option: ");
	}

	private static void insertDataMenu(Scanner scanner, CsvFacade csvFacade) {
		System.out.println("Insert Data Menu:");
		System.out.println("1. Insert Team");
		System.out.println("2. Insert User");
		System.out.print("Choose an option: ");
		int choice = scanner.nextInt();

		scanner.nextLine(); // Consume newline character

		switch (choice) {
		case 1:
			System.out.print("Enter Team Name: ");
			String teamName = scanner.nextLine();
			csvFacade.addTeam(teamName);
			break;
		case 2:
			System.out.print("Enter User Name: ");
			String userName = scanner.nextLine();
			System.out.print("Enter User NIM: ");
			String userNim = scanner.nextLine();
			System.out.print("Enter Team Name: ");
			String userTeamName = scanner.nextLine();
			csvFacade.addUser(userName, userNim, userTeamName);
			break;
		default:
			System.out.println("Invalid choice.");
		}
	}

	private static void showMenu(Scanner scanner, CsvFacade csvFacade) {
		System.out.println("Show Menu:");
		System.out.println("1. Show Teams");
		System.out.println("2. Show Users");
		System.out.print("Choose an option: ");
		int choice = scanner.nextInt();

		scanner.nextLine(); // Consume newline character

		switch (choice) {
		case 1:
			// Implement Show Teams
			break;
		case 2:
			// Implement Show Users
			break;
		default:
			System.out.println("Invalid choice.");
		}
	}
}
