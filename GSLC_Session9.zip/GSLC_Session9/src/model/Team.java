package model;

public class Team extends Model {
	// Implementation for Team model
}
