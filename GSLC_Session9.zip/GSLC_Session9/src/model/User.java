package model;

public class User extends Model {
	// Implementation for User model
}
