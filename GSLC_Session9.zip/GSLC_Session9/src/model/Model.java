package model;

public abstract class Model {
	// Common properties and methods for User and Team models
}
