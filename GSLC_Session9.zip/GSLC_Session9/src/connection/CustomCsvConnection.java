package connection;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public class CustomCsvConnection {
	private static CustomCsvConnection instance = null;

	private CustomCsvConnection() {
	}

	public static synchronized CustomCsvConnection getInstance() {
		if (instance == null) {
			instance = new CustomCsvConnection();
		}
		return instance;
	}

	public List<String[]> readCsvFile(String filePath) {
		return null;

	}

	public void writeCsvFile(String filePath, List<String[]> dataLines) {

	}
}
