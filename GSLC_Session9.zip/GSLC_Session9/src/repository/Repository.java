package repository;

import connection.CustomCsvConnection;

import java.util.List;

public interface Repository<T> {
	List<T> find(String column, String[] conditions, Boolean joinTable, String tableName,
			CustomCsvConnection connection);

	T findOne(String column, String[] conditions, Boolean joinTable, String tableName, CustomCsvConnection connection);

	T insert(String[] data, CustomCsvConnection connection);
}
