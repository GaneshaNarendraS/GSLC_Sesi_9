package repository;

import connection.CustomCsvConnection;
import model.User;

import java.util.List;

public class UserRepository implements Repository<User> {

}
