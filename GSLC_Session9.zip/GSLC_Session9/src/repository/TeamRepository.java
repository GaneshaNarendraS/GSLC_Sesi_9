package repository;

import connection.CustomCsvConnection;
import models.Team;

import java.util.List;

public class TeamRepository implements Repository<Team> {

}
