package com.gslc.facade;

import com.gslc.connection.CustomCsvConnection;
import com.gslc.models.User;
import com.gslc.models.Team;
import com.gslc.repository.UserRepository;
import com.gslc.repository.TeamRepository;

import java.util.List;

public class CsvFacade {
	private UserRepository userRepository;
	private TeamRepository teamRepository;

	public CsvFacade(CustomCsvConnection connection, String userCsvPath, String teamCsvPath) {
		this.userRepository = new UserRepository(connection, userCsvPath);
		this.teamRepository = new TeamRepository(connection, teamCsvPath);
	}

	// Implementation of menu-related methods
}
