package com.gslc;

import com.gslc.connection.CustomCsvConnection;
import com.gslc.facade.CsvFacade;
import com.gslc.menu.Menu;
import com.gslc.models.User;
import com.gslc.models.Team;

import java.util.List;

public class Main {
	public static void main(String[] args) {
		CustomCsvConnection connection = CustomCsvConnection.getCustomInstance();
		String userCsvPath = "C:/Users/Acer/Downloads/GSLC-Session-9-main/GSLC-Session-9-main/user.csv";
		String teamCsvPath = "C:/Users/Acer/Downloads/GSLC-Session-9-main/GSLC-Session-9-main/teams.csv";

		CsvFacade csvFacade = new CsvFacade(connection, userCsvPath, teamCsvPath);
		Menu menu = new Menu(csvFacade);
		menu.displayMenu();
	}
}
